document.addEventListener('DOMContentLoaded', function() {
    const slides = ['p1.jpg', 'p2.jpg','p3.jpg'];
    let currentSlide = 0;

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        document.getElementById('slide').src = slides[currentSlide];
    }

    setInterval(nextSlide, 3000); // 每3秒切换照片
});
